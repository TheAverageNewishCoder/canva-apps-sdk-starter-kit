const platform = window.canva.platform;
export const getPlatformInfo = platform.getPlatformInfo.bind(platform);
export const requestOpenExternalUrl = platform.requestOpenExternalUrl.bind(platform);
export const appProcess = window.canva.appProcess;
